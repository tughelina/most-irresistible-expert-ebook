# Transformative Expert Ebook — Source Framework

Based on Chantal's supplied English Classroom cheat sheet and her German five-page handout. These are **editorial functions**, not ten required chapters.

1. Define the reader's realistic before/after transformation.
2. Articulate one central thesis.
3. Develop the unique mechanism, distinguish it from typical approaches, and explain its steps.
4. Cover useful functions: promise, audience recognition, reader gains, why now, new approach, limitations of prior model, deeper cause, how mechanism works, personal test, aligned next step.
5. Where useful, use pattern → reflection → decision tool → exercise → next move.
6. Anchor author values, philosophy, ethical boundaries, and relevant real origin/recognition/proof/decision stories.
7. Help the reader test the explanation and retain independent judgment, including the ability to say no.
8. Use research to support facts, story for recognition, method for process, reflection for testability, and action for application.
9. Give real value before any paid offer; make any offer an honest next stage.
10. Final reader check: understood, new clarity, deeper cause, personal test, concrete decision, next step, self-sufficiency, free choice.

The author's later requirements add: mandatory upfront market and method research, a *single* major desirable problem, author-interview-led content, writing BEFORE reverse-engineered chapters (max 5), natural searchable chapter headings, objection-handling subtitles, story-led offer visibility, and single clear final CTA (default clarity call).

Do not claim the source handout independently proves market demand, SEO effects, or financial behavior.

## Miles-derived logic, as described in the author’s prior discussion

Use the progression: validate the familiar problem → examine previous explanations fairly → reveal and test the deeper cause → teach the authentic unique mechanism → justify **why** its causal steps plausibly work (evidence, limitations, counterexamples) → reduce the solution to a **few memorable principles** that enable independent application. Do not attribute specific quotes or external research findings to Miles without a primary source. These functions are NOT preset chapter headings.
