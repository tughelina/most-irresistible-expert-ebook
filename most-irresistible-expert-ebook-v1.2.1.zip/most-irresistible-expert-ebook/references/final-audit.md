# Mandatory final audit checklist

Mark each PASS / FAIL / NOT CHECKED and quote relevant evidence or section.

- Research preceded substantive drafting; evidence ledger exists and sources were genuinely checked.
- One clearly defined reader, one dominant painful/desirable problem, one realistic independent reader shift.
- Market demand / willingness to pay / science claims separated into evidence, inference and hypothesis.
- Author's mechanism is specific, authentic, comprehensible and not falsely universal. Each causal link is explained with evidence or marked hypothesis; counterevidence and limitations are acknowledged.
- Solution is reduced to a few memorable actionable principles, without loss of important caveats.
- Author's actual stories and cases are accurately attributed, authorized and not invented.
- Each embedded offer reference illustrates a relevant method or natural next step, not a forced advertisement.
- Body was developed through transformation milestones **before** chapter headings were finalized.
- Chapter count 1–5; each chapter offers a distinct reader recognition, decision, or action.
- Every chapter title aligns with a supported search intent and actual content; every subtitle addresses a genuine objection.
- No keyword stuffing, unsupported rankings, fabricated search volume, or AI discoverability guarantee.
- Facts cited; claims traceable; quotations and permissions sound; contradictory evidence treated fairly.
- Manuscript voice is author's; no filler, generic platitudes, duplicated paragraphs or unsupported superlatives.
- Reader can test the thesis and freely disagree / decline commercial support.
- Valuable independent first result exists; the next offer doesn't contain withheld essentials.
- Foreword: author-written/co-written or actual contributor with documented consent and approved text; no implied endorsement.
- Afterword: author-written or explicitly labelled “Afterword by the AI writing partner”; no invented AI feelings, memories, firsthand client experiences or independent endorsement.
- Final CTA comes **after** afterword (or in a separate final invitation), not buried in an AI afterword.
- Reader objection ledger lists source for every subtitle objection, or explicitly flags unverified objections as a blocking issue.
- One primary final CTA: relevant audience, appropriate next stage, clear wording and verified URL (or placeholder marked).
- Manuscript, ledgers and audit accurately labelled complete/partial; author has approved unresolved substantive decisions.

## Red-team prompts

1. Which sentence sounds plausible but has no evidence?
2. Which story, outcome or endorsement may be invented or overinterpreted?
3. If all promotions were removed, would the reader still gain something usable?
4. What would a well-informed critic question about the causal mechanism?
5. Is any subtitle addressing an objection nobody actually expressed?
6. Could a searcher tell from the chapter title what question it answers?
7. Does the CTA fit the transformation just delivered, or force a jump?

Do not mark a gate PASS based solely on the assistant's assertion; identify inspectable work or record NOT CHECKED.
