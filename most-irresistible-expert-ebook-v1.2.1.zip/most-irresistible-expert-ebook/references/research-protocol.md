# Research protocol & evidence ledger

## Sources in preferred order

1. Author's real, consented customer interviews, support questions, discovery-call notes and purchasing patterns (private; anonymize).
2. Domain-appropriate reliable empirical or official research; note publication date, scope and limits.
3. Public reader language from relevant communities, reviews, Q&A and forums; treat as anecdotal and selection-biased.
4. Competitor offers, books and educational materials to understand messages and gaps; not proof of efficacy or purchase volume.
5. Search trend and query tools, only if actually accessible; record geography, timeframe and method, without inventing statistics.

## Evidence entry template

- Claim / candidate problem:
- Evidence category: observed / inferred / hypothesis
- Source title and link (or author-provided confidential evidence ID):
- Publication date (if known) / accessed date:
- Geography, segment, language:
- What it directly establishes (one sentence):
- What it **does not** establish:
- Credibility and bias / counterevidence:
- Exact reader language (short, permitted quotations only):
- Reader objections / doubts (verbatim where permitted, source URL or private evidence ID):
- Fit to author's method and offer:
- Confidence: high / medium / low, with reason:

## Candidate comparison

Score qualitatively (high/medium/low/unknown), not false-precision numbers: reader urgency, desired result, evidence of effort/spend, fit to mechanism, differentiation, ebook-achievable independent result, ethical risks. Show at most three, recommend one, and obtain author choice. Search interest ≠ payment willingness; popular complaint ≠ verified cause.
