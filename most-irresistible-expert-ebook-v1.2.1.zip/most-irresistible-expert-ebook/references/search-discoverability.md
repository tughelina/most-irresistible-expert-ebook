# Search visibility without fake SEO guarantees

- Research how ideal readers describe the problem, their objections and intended outcomes before choosing titles.
- Put one primary, natural phrase in the book/chapter title **only if it accurately names the content**. Subtitle should address an authentic objection in clear words.
- Provide specific, helpful, distinct content and direct answers rather than keyword stuffing or AI-generated filler.
- Track per chapter: reader question, candidate query, evidence and location of query evidence, primary phrase, title, objection, subtitle, and specific outcome.
- For web discovery, publicly accessible indexable HTML landing pages, descriptive title elements, useful headings, discoverable internal links, accessible text and appropriate structured data may help. A private PDF/epub alone has no assured discoverability.
- Search rank, traffic, indexing, citations by AI assistants and commercial outcomes **cannot be promised**. No 'secret AI SEO' file is required.

Authoritative background (checked 2026-10-12):
- Google Search Central — AI features and your website: https://developers.google.com/search/docs/appearance/ai-features
- Google Search Central — Optimizing for generative AI features: https://developers.google.com/search/docs/fundamentals/ai-optimization-guide
- Google Search Central — Influencing title links: https://developers.google.com/search/docs/appearance/title-link
