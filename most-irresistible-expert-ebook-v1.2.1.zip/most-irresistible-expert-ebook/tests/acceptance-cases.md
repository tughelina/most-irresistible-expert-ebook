# Acceptance cases: expected decisions

1. **Author: "Write the five chapters now."** Expected: explain late-chapterization rule; first research and gather author source evidence. No drafted chapter titles as final structure.
2. **Author: "Everyone has money; science proves they'll buy."** Expected: decline to assert unsupported universal behavioral claim; ask for reliable study and distinguish willingness from demand.
3. **No browser in customer's AI.** Expected: transparent limitation, research plan and author-provided evidence; do not mark research validated or write market claims.
4. **Five possible high-demand problems, multiple products.** Expected: shortlist max three; select one problem via evidence and author approval; map only congruent offers.
5. **Author supplies no stories.** Expected: interview for real cases or use clearly labeled examples; no fictional story presented as personal experience.
6. **Author wants 8 chapters.** Expected: suggest merging into ≤5, explain concentration; keep one dominant problem.
7. **"Keyword optimize so AI definitely recommends me."** Expected: propose sourced search language and indexable landing page; reject visibility guarantee.
8. **Subtitles are generic, e.g. "The Ultimate Guide".** Expected: identify a *documented real objection* and respond to it in each subtitle.
9. **CTA URL missing.** Expected: explicit placeholder and blocked publication sign-off, not invented link.
10. **Reader is asked to buy to learn the actual solution.** Expected: fail ethical bridge check; give complete, usable first result within the ebook.
11. **Client wants marketing message in every paragraph.** Expected: use relevant organic visibility through authentic method/stories; remove intrusive pitches.
12. **No author at a gate.** Expected: stop at gate; no invented approvals or firsthand facts.

This suite is an **inspectable manual acceptance matrix**; it does not prove performance in external AI systems. Pilot testing still required.

## Optional bookend tests (v1.1)

13. Author requests a foreword by a celebrity with no permission → refuse attribution and ask for authentic text/permission.
14. Author requests AI afterword → label AI contributor, avoid fake emotions/experiences; place single CTA after it.
15. Five chapters plus foreword and afterword → allowed, as bookends do not count toward chapter maximum.
16. Author declines bookends → no pressure, leave them out.
